#!/bin/bash -l

for a in $(seq 2 1 4)
do
	for b in $(seq 4 1 6)
	do
		mkdir "a$a""b$b"
		cd "a$a""b$b"
		qsub -N log_"a$a""b$b" -l h_rt=11:59:59 ../exec.sh $a $b
		cd ..
	done
done