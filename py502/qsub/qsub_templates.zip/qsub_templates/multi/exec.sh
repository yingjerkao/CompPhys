#!/bin/bash -l

#$ -P py502
#$ -j y


module load julia/1.7.3

echo "Start $JOB_NAME - $JOB_ID: $(date)"
julia ../program.jl $1 $2
wait
echo "End $JOB_NAME - $JOB_ID: $(date)"