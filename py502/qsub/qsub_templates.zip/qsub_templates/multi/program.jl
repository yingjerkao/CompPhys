function log_test(a, b)
	
	c = log(a*b)
	d = log(a) + log(b)

	f = open("res.csv", "w")
	println(f, a, ",", b, ",", c, ",", d)
	close(f)
end

a = parse(Float64, ARGS[1])
b = parse(Float64, ARGS[2])

log_test(a, b)