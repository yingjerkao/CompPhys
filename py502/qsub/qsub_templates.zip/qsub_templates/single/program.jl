function log_test()
	a = 2
	b = 3

	c = log(a*b)
	d = log(a) + log(b)

	f = open("res.csv", "w")
	println(f, c, ",",d)
	close(f)
end

log_test()

