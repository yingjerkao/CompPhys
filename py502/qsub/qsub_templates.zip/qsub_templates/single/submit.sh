#!/bin/bash -l


qsub -N log_test -l h_rt=11:59:59 exec.sh
